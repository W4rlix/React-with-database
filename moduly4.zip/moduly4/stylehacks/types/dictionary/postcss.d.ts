export const ATRULE: "atrule";
export const DECL: "decl";
export const RULE: "rule";
