'use strict';
const FF_2 = 'firefox 2';
const IE_5_5 = 'ie 5.5';
const IE_6 = 'ie 6';
const IE_7 = 'ie 7';
const IE_8 = 'ie 8';
const OP_9 = 'opera 9';

module.exports = { FF_2, IE_5_5, IE_6, IE_7, IE_8, OP_9 };
