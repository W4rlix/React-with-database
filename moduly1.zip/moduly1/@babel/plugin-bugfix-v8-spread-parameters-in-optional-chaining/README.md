# @babel/plugin-bugfix-v8-spread-parameters-in-optional-chaining

> Transform optional chaining operators to workaround https://crbug.com/v8/11558

See our website [@babel/plugin-bugfix-v8-spread-parameters-in-optional-chaining](https://babeljs.io/docs/en/babel-plugin-bugfix-v8-spread-parameters-in-optional-chaining) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-bugfix-v8-spread-parameters-in-optional-chaining
```

or using yarn:

```sh
yarn add @babel/plugin-bugfix-v8-spread-parameters-in-optional-chaining --dev
```
