'use strict';

module.exports = null;
